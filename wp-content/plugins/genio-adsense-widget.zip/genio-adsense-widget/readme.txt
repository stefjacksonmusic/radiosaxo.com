=== Genio Adsense Widget ===
Contributors: geniolabs
Tags: Google Adsense, Widget
Requires at least: 3.0.1
Tested up to: 3.9.
License: GPLv2

Genio Adsense Widget is a simple widget that allow you to put adsense's Ads Code in a widget and avoid the errors and mishandling in the output.

== Description ==
<p style=\"margin: 5px 0px 15px; padding: 0px; border: 0px; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 12px; line-height: 19.200000762939453px; vertical-align: baseline; color: #666666;\">Genio Adsense Widget is a simple plugin that let you put your Google Adsense Code on page sides as a widget.  
Simple to use:</p> <ol style=\"margin: 5px 0px 15px; padding: 0px; border: 0px; font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; font-size: 12px; line-height: 19.200000762939453px; vertical-align: baseline; list-style-position: inside; color: #666666;\"> <li style=\"margin: 0px; padding: 3px 0px; border: 0px; font-family: inherit; font-size: inherit; font-style: inherit; font-variant: inherit; font-weight: inherit; line-height: inherit; vertical-align: baseline;\"><span style=\"margin: 0px; padding: 0px; border: 0px; font-family: inherit; font-size: inherit; font-style: inherit; font-variant: inherit; font-weight: inherit; line-height: 1.4; vertical-align: baseline;\">install the widget,</span></li> <li style=\"margin: 0px; padding: 3px 0px; border: 0px; font-family: inherit; font-size: inherit; font-style: inherit; font-variant: inherit; font-weight: inherit; line-height: inherit; vertical-align: baseline;\"><span style=\"margin: 0px; padding: 0px; border: 0px; font-family: inherit; font-size: inherit; font-style: inherit; font-variant: inherit; font-weight: inherit; line-height: 1.4; vertical-align: baseline;\">add Genio Adsens Widget to a sidebar,</span></li> <li style=\"margin: 0px; padding: 3px 0px; border: 0px; font-family: inherit; font-size: inherit; font-style: inherit; font-variant: inherit; font-weight: inherit; line-height: inherit; vertical-align: baseline;\"><span style=\"margin: 0px; padding: 0px; border: 0px; font-family: inherit; font-size: inherit; font-style: inherit; font-variant: inherit; font-weight: inherit; line-height: 1.4; vertical-align: baseline;\">fill the widget with Title and Adsense Code afforded by Google,</span></li> <li style=\"margin: 0px; padding: 3px 0px; border: 0px; font-family: inherit; font-size: inherit; font-style: inherit; font-variant: inherit; font-weight: inherit; line-height: inherit; vertical-align: baseline;\"><span style=\"margin: 0px; padding: 0px; border: 0px; font-family: inherit; font-size: inherit; font-style: inherit; font-variant: inherit; font-weight: inherit; line-height: 1.4; vertical-align: baseline;\">and it’s Done !</span></li> </ol> <div>
  <span style=\"font-family: \'Helvetica Neue\', Arial, Helvetica, sans-serif; color: #666666;\"><span style=\"font-size: 12px; line-height: 16.799999237060547px;\">For further informations and demo please visit the <a href=\"http://www.geniolabs.com/genio-adsense-widget-plugin/\" target=\"_blank\" title=\"Adsense Worpdress Widget\">plugin's page.</a></span></span>
</div>

== Installation ==
Extract the zip file and just drop the contents in the wp-content/plugins/ directory of your WordPress installation and then activate the Plugin from Plugins page.

== Screenshots ==
1. ADd Genio Adsense Widget